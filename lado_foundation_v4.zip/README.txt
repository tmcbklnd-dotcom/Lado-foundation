Lado Foundation v4 (Final) - Two pages. UPI ID: thechallanger@ybl
